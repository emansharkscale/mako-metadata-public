import { LightningElement, track, wire } from 'lwc';
import getObjectNames from '@salesforce/apex/ObjectSelector.getObjectNames';
import processStandardObjectMetadata from '@salesforce/apex/StandardObjectMetadataComposite.processStandardObjectMetadata';
import processCustomObjectMetadata from '@salesforce/apex/CustomObjectMetadataComposite.processCustomObjectMetadata';


export default class ObjectSelector extends LightningElement {
    @track standardObjectOptions = [];
    @track customObjectOptions = [];

    @track selectedStandardObjects = [];
    @track selectedCustomObjects = [];

    @track selectedStandardMetadataOptions = [];
    @track selectedCustomMetadataOptions = [];

    @track standardMetadataOptions = [
        { label: 'Retrieve Field metadata', value: 'standardFieldMetadata' },
        { label: 'Retrieve Validation Rules metadata', value: 'standardValidationRulesMetadata' },
        { label: 'Retrieve Record Type metadata', value: 'standardRecordTypeMetadata' }
    ];
    @track customMetadataOptions = [
        { label: 'Retrieve Field metadata', value: 'customFieldMetadata' },
        { label: 'Retrieve Validation Rules metadata', value: 'customValidationRulesMetadata' },
        { label: 'Retrieve Record Type metadata', value: 'customRecordTypeMetadata' }
    ];
    
    @track metadataResult;  //  variable to hold metadata result
    @track loading = false; //  variable to indicate loading state

    // Utility function to sort the array based on 'label'
    sortOptionsAlphabetically(options) {
        return options.sort((a, b) => a.label.localeCompare(b.label));
    }

    @wire(getObjectNames)
    wiredObjects({ error, data }) {
        if (data) {
            const standardObjects = [];
            const customObjects = [];
            data.forEach(obj => {
                if (obj.endsWith('__c')) {
                    customObjects.push({ label: obj, value: obj });
                } else {
                    standardObjects.push({ label: obj, value: obj });
                }
            });

            // Sort the options alphabetically
            this.standardObjectOptions = this.sortOptionsAlphabetically(standardObjects);
            this.customObjectOptions = this.sortOptionsAlphabetically(customObjects);
        } else if (error) {
            console.error('Error fetching objects:', error);
        }
    }

    handleStandardObjectChange(event) {
        this.selectedStandardObjects = event.detail.value;
        console.log('Debug: Selected standard objects:', this.selectedStandardObjects);
        console.log('Debug: Entire Event:', JSON.stringify(event.detail));
    }

    handleCustomObjectChange(event) {
        this.selectedCustomObjects = event.detail.value;
        console.log('Debug: Selected custom objects:', this.selectedCustomObjects);
        console.log('Debug: Entire Event:', JSON.stringify(event.detail));
    }

    handleStandardMetadataOptionChange(event) {
    this.selectedStandardMetadataOptions = event.detail.value;
    console.log('Debug: Selected Metadata Options:', this.selectedStandardMetadataOptions);
    console.log('Debug: Entire Event:', JSON.stringify(event.detail));
    }

    handleCustomMetadataOptionChange(event) {
    this.selectedCustomMetadataOptions = event.detail.value;
    console.log('Debug: Selected Metadata Options:', this.selectedCustomMetadataOptions);
    console.log('Debug: Entire Event:', JSON.stringify(event.detail));
    }


    handleStdObjectProcessing() {
        this.loading = true;  // Set loading to true
        console.log("About to call Apex method");
        
        processStandardObjectMetadata({
            selectedStandardObjects: this.selectedStandardObjects,
            selectedStandardMetadataOptions: this.selectedStandardMetadataOptions
        })
        .then(result => {
            this.loading = false;  // Set loading to false
            this.metadataResult = result;  // Store the result
            
            console.log('Successfully processed standard object metadata:', result);
        })
        .catch(error => {
            this.loading = false;  // Set loading to false
            console.error('Error in processing standard object metadata:', error);
            // Here you could update a user-friendly error message
        });
        
        console.log("Apex method called");
    }


    handleCustomObjectProcessing() {
        this.loading = true;  // Set loading to true
        console.log("About to call Apex method");

        processCustomObjectMetadata({
            selectedCustomObjects: this.selectedCustomObjects,
            selectedCustomMetadataOptions: this.selectedCustomMetadataOptions
        })
        .then(result => {
            this.loading = false;  // Set loading to false
            this.metadataResult = result;  // Store the result
            
            console.log('Successfully processed custom object metadata:', result);
        })
        .catch(error => {
            this.loading = false;  // Set loading to false
            console.error('Error in processing custom object metadata:', error);
            // Here you could update a user-friendly error message
        });
        
        console.log("Apex method called");
        console.log('Selected Custom Objects:', this.selectedCustomObjects);
        console.log('Selected Custom Object Metadata Options:', this.selectedCustomMetadataOptions);
    }
}